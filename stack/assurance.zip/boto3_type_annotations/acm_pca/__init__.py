from boto3_type_annotations.acm_pca.client import Client
    
__all__ = (
    'Client'
)
