from boto3_type_annotations.apigateway.client import Client
    
__all__ = (
    'Client'
)
