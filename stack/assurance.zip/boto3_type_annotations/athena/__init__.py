from boto3_type_annotations.athena.client import Client
    
__all__ = (
    'Client'
)
