from boto3_type_annotations.comprehendmedical.client import Client
    
__all__ = (
    'Client'
)
