from boto3_type_annotations.config.client import Client
    
__all__ = (
    'Client'
)
