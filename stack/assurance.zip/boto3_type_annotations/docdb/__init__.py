from boto3_type_annotations.docdb.client import Client
    
__all__ = (
    'Client'
)
