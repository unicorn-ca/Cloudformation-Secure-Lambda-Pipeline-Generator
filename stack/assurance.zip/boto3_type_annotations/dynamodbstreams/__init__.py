from boto3_type_annotations.dynamodbstreams.client import Client
    
__all__ = (
    'Client'
)
