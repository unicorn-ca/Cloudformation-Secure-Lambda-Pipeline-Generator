from boto3_type_annotations.iot1click_projects.client import Client
    
__all__ = (
    'Client'
)
