from boto3_type_annotations.iot_jobs_data.client import Client
    
__all__ = (
    'Client'
)
