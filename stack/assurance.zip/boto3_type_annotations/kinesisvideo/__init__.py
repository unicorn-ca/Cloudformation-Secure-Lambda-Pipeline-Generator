from boto3_type_annotations.kinesisvideo.client import Client
    
__all__ = (
    'Client'
)
