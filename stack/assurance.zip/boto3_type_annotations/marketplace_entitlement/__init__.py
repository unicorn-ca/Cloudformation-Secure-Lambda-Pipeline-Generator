from boto3_type_annotations.marketplace_entitlement.client import Client
    
__all__ = (
    'Client'
)
