from boto3_type_annotations.mediaconvert.client import Client
    
__all__ = (
    'Client'
)
