from boto3_type_annotations.mediatailor.client import Client
    
__all__ = (
    'Client'
)
