from boto3_type_annotations.neptune.client import Client
    
__all__ = (
    'Client'
)
