from boto3_type_annotations.resource_groups.client import Client
    
__all__ = (
    'Client'
)
