from boto3_type_annotations.route53domains.client import Client
    
__all__ = (
    'Client'
)
