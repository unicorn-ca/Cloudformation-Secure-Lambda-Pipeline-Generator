from boto3_type_annotations.alexaforbusiness.client import Client
    
__all__ = (
    'Client'
)
