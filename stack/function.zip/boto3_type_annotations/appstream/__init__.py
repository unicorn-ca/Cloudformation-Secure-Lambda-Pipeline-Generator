from boto3_type_annotations.appstream.client import Client
    
__all__ = (
    'Client'
)
