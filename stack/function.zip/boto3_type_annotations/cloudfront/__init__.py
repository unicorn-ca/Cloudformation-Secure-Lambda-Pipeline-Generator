from boto3_type_annotations.cloudfront.client import Client
    
__all__ = (
    'Client'
)
