from boto3_type_annotations.cloudsearch.client import Client
    
__all__ = (
    'Client'
)
