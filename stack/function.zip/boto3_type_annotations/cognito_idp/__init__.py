from boto3_type_annotations.cognito_idp.client import Client
    
__all__ = (
    'Client'
)
