from boto3_type_annotations.connect.client import Client
    
__all__ = (
    'Client'
)
