from boto3_type_annotations.cur.client import Client
    
__all__ = (
    'Client'
)
