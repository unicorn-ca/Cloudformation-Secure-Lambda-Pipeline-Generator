from boto3_type_annotations.efs.client import Client
    
__all__ = (
    'Client'
)
