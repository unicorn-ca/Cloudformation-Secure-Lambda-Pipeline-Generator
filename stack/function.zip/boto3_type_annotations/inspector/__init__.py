from boto3_type_annotations.inspector.client import Client
    
__all__ = (
    'Client'
)
