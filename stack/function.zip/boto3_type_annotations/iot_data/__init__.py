from boto3_type_annotations.iot_data.client import Client
    
__all__ = (
    'Client'
)
