from boto3_type_annotations.lambda_.client import Client
    
__all__ = (
    'Client'
)
