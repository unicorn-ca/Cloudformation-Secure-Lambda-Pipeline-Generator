from boto3_type_annotations.machinelearning.client import Client
    
__all__ = (
    'Client'
)
