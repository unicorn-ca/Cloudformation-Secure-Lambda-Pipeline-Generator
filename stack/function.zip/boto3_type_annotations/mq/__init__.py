from boto3_type_annotations.mq.client import Client
    
__all__ = (
    'Client'
)
