from boto3_type_annotations.polly.client import Client
    
__all__ = (
    'Client'
)
